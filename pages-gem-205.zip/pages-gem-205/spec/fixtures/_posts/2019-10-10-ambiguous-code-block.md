---
title: Ambiguous Code Block
---

Testing an ambiguous code block. Rouge gets tripped up by this.

## **Header**

This is a paragraph.

    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">

    <html>

    <head>

    </head>

    <body>

    </body>

    </html>

This is a paragraph.
