# frozen_string_literal: true

module GitHubPages
  VERSION = 205
end
